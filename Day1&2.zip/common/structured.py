"""Structured output: JSON Schema from Pydantic, parsing, validation and retries.

Two layers of defence:
1. JSON Schema (strict mode) makes the model return the right *shape*.
2. Pydantic validators check *business rules* the schema cannot express
   (formats, word limits, cross-field rules). If they fail, we send the errors
   back to the model and ask it to fix its output (bounded retries).
"""
import copy
import logging
from dataclasses import dataclass
from typing import Generic, TypeVar

from pydantic import BaseModel, ValidationError

from common.llm import chat

log = logging.getLogger("structured")
T = TypeVar("T", bound=BaseModel)


class StructuredOutputError(Exception):
    def __init__(self, message: str, attempts: int, last_output: str):
        super().__init__(message)
        self.attempts = attempts
        self.last_output = last_output


@dataclass
class StructuredResult(Generic[T]):
    value: T
    attempts: int
    raw: str


def to_strict_schema(model_cls: type[BaseModel]) -> dict:
    """Convert a Pydantic model's JSON Schema into OpenAI strict-mode format.

    Strict mode needs: additionalProperties=false on every object, every
    property listed in "required" (use `X | None` for optional values),
    and no unsupported keywords such as "default".
    Note: don't name a field "title" or "default" in models used here.
    """
    schema = copy.deepcopy(model_cls.model_json_schema())

    def fix(node):
        if isinstance(node, dict):
            node.pop("title", None)
            node.pop("default", None)
            if node.get("type") == "object" and "properties" in node:
                node["additionalProperties"] = False
                node["required"] = list(node["properties"].keys())
            for value in node.values():
                fix(value)
        elif isinstance(node, list):
            for item in node:
                fix(item)

    fix(schema)
    return schema


def format_validation_errors(err: ValidationError) -> str:
    lines = []
    for e in err.errors():
        loc = ".".join(str(p) for p in e["loc"]) or "(root)"
        lines.append(f"- {loc}: {e['msg']}")
    return "\n".join(lines)


def call_structured(
    messages: list[dict],
    model_cls: type[T],
    *,
    client=None,
    model: str | None = None,
    max_attempts: int = 3,
    mode: str = "json_schema",  # "json_schema" (strict) or "json_object" (JSON mode only)
    temperature: float | None = 0,
) -> StructuredResult[T]:
    """Call the model until its output validates against `model_cls`, or give up."""
    if mode == "json_schema":
        response_format = {
            "type": "json_schema",
            "json_schema": {
                "name": model_cls.__name__,
                "schema": to_strict_schema(model_cls),
                "strict": True,
            },
        }
    elif mode == "json_object":
        response_format = {"type": "json_object"}
    else:
        raise ValueError(f"unknown mode: {mode}")

    extra = {"temperature": temperature} if temperature is not None else {}
    convo = list(messages)
    last_raw, last_error = "", ""

    for attempt in range(1, max_attempts + 1):
        resp = chat(convo, client=client, model=model, response_format=response_format, **extra)
        choice = resp.choices[0]

        refusal = getattr(choice.message, "refusal", None)
        if refusal:  # safety refusal: retrying the same request won't help
            raise StructuredOutputError(f"model refused: {refusal}", attempt, "")

        raw = choice.message.content or ""
        if choice.finish_reason == "length":
            error = "- output was cut off at the token limit; return shorter values"
        else:
            try:
                value = model_cls.model_validate_json(raw)  # parse + validate in one step
                if attempt > 1:
                    log.info("valid output on attempt %d", attempt)
                return StructuredResult(value=value, attempts=attempt, raw=raw)
            except ValidationError as e:
                error = format_validation_errors(e)

        log.warning("attempt %d/%d failed validation:\n%s", attempt, max_attempts, error)
        last_raw, last_error = raw, error
        # Feed the exact errors back so the model can repair its own output.
        convo = convo + [
            {"role": "assistant", "content": raw},
            {
                "role": "user",
                "content": "Your previous output failed validation:\n"
                f"{error}\n"
                "Fix these problems and return ONLY the corrected JSON object.",
            },
        ]

    raise StructuredOutputError(
        f"no valid output after {max_attempts} attempts:\n{last_error}", max_attempts, last_raw
    )
