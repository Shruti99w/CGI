"""Thin wrapper around the OpenAI client.

Production habits shown here:
- one shared client (connection reuse) with a timeout and automatic retries
- every call logs model, latency, token usage and finish_reason
- the client can be injected, so code is testable without network access
"""
import logging
import os
import time
from functools import lru_cache

from common.config import get_settings

log = logging.getLogger("llm")


def setup_logging() -> None:
    logging.basicConfig(
        level=os.getenv("LOG_LEVEL", "INFO").upper(),
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )
    # The SDK's HTTP logs are noisy; keep them quiet unless debugging.
    logging.getLogger("httpx").setLevel(logging.WARNING)


@lru_cache(maxsize=1)
def get_client():
    from openai import OpenAI  # imported lazily so tests run without the SDK

    s = get_settings()
    # max_retries: the SDK retries 408/429/5xx and connection errors with backoff.
    return OpenAI(api_key=s.api_key, timeout=s.timeout_s, max_retries=s.max_retries)


def chat(messages: list[dict], *, model: str | None = None, client=None, **kwargs):
    """Send one chat completion request and log what it cost."""
    client = client or get_client()
    model = model or get_settings().model
    start = time.perf_counter()
    resp = client.chat.completions.create(model=model, messages=messages, **kwargs)
    latency_ms = (time.perf_counter() - start) * 1000
    usage = resp.usage
    log.debug(
        "model=%s latency_ms=%.0f prompt_tokens=%s completion_tokens=%s finish=%s",
        model,
        latency_ms,
        getattr(usage, "prompt_tokens", None),
        getattr(usage, "completion_tokens", None),
        resp.choices[0].finish_reason,
    )
    return resp
