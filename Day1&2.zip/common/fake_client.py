"""A stand-in for the OpenAI client that returns scripted responses.

Used by the tests and by offline demos, so retry and validation logic can be
exercised without an API key or network access.
"""
from types import SimpleNamespace


class FakeClient:
    def __init__(self, outputs: list[str], finish_reason: str = "stop"):
        self._outputs = list(outputs)
        self._finish_reason = finish_reason
        self.calls: list[dict] = []
        self.chat = SimpleNamespace(completions=SimpleNamespace(create=self._create))

    def _create(self, **kwargs):
        self.calls.append(kwargs)
        if not self._outputs:
            raise RuntimeError("FakeClient ran out of scripted outputs")
        message = SimpleNamespace(content=self._outputs.pop(0), refusal=None, tool_calls=None)
        return SimpleNamespace(
            choices=[SimpleNamespace(message=message, finish_reason=self._finish_reason)],
            usage=SimpleNamespace(prompt_tokens=10, completion_tokens=5, total_tokens=15),
        )
