"""Module 2 / Step 3 - Structured output with JSON Schema.

Run:  uv run python -m module2.step3_json_schema

Three levels of "give me JSON", weakest to strongest:
  A. Ask nicely in the prompt   -> may add prose or ```json fences; json.loads can fail
  B. JSON mode (json_object)    -> always valid JSON, but any shape (missing/extra keys)
  C. Strict JSON Schema         -> valid JSON in exactly your schema (keys, types, enums)

Even C can't check business rules (email format, word limits). That's Step 4.
"""
import json

from pydantic import ValidationError

from common.llm import chat, setup_logging
from common.structured import call_structured, to_strict_schema
from module2.schemas import TicketFields

TICKET = ("Hi, I'm Neha Sharma (neha.sharma@example.com). I ordered a Bluetooth speaker, "
          "order ORD-482913, and it arrived with a cracked casing. I'd like a replacement please.")

FIELDS_HINT = ("customer_name, customer_email, order_id, product, category, priority, "
               "sentiment, summary, evidence")


def try_parse(label: str, raw: str) -> None:
    print(f"\n--- {label}\nRAW: {raw[:300]}{'...' if len(raw) > 300 else ''}")
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as e:
        print(f"json.loads FAILED: {e}")
        return
    try:
        TicketFields.model_validate(data)
        print("Valid against TicketFields: YES")
    except ValidationError as e:
        print(f"Valid against TicketFields: NO ({e.error_count()} errors), e.g. {e.errors()[0]['msg']}")


def main() -> None:
    setup_logging()
    base = [{"role": "user", "content": f"Extract these fields as JSON: {FIELDS_HINT}.\n\nTicket: {TICKET}"}]

    # A. Prompt only
    raw_a = chat(base, temperature=0).choices[0].message.content
    try_parse("A. prompt only", raw_a)

    # B. JSON mode: syntax guaranteed, shape not. (The word "JSON" must appear in the messages.)
    raw_b = chat(base, temperature=0, response_format={"type": "json_object"}).choices[0].message.content
    try_parse("B. json_object mode", raw_b)

    # C. Strict JSON Schema generated from the Pydantic model
    schema = to_strict_schema(TicketFields)
    print("\n--- C. strict json_schema\nSchema sent to the API (excerpt):")
    print(json.dumps(schema["properties"]["priority"], indent=2))
    result = call_structured(base, TicketFields, max_attempts=1)
    print("Typed object:", result.value.model_dump())
    print("Access like code:", result.value.priority, "|", result.value.order_id)


if __name__ == "__main__":
    main()
