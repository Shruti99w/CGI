"""Batch-run the ticket extractor over a JSONL file.

Run:  uv run python -m module2.run_extractor
      uv run python -m module2.run_extractor --input module2/data/tickets.jsonl --limit 3

Writes:
  out/results.jsonl   one line per successfully extracted ticket
  out/failures.jsonl  tickets that failed validation after all retries (for review)
"""
import argparse
import json
import sys
from pathlib import Path

from common.llm import setup_logging
from module2.extractor import extract_ticket


def load_tickets(path: Path) -> list[dict]:
    tickets = []
    for line_no, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
            tickets.append({"id": str(row["id"]), "text": str(row["text"])})
        except (json.JSONDecodeError, KeyError) as e:
            print(f"skipping line {line_no}: {e}", file=sys.stderr)
    return tickets


def main() -> None:
    parser = argparse.ArgumentParser(description="Extract fields from support tickets")
    parser.add_argument("--input", type=Path, default=Path("module2/data/tickets.jsonl"))
    parser.add_argument("--output-dir", type=Path, default=Path("out"))
    parser.add_argument("--max-attempts", type=int, default=3)
    parser.add_argument("--limit", type=int, default=None)
    args = parser.parse_args()

    setup_logging()
    tickets = load_tickets(args.input)[: args.limit]
    args.output_dir.mkdir(parents=True, exist_ok=True)
    results_path = args.output_dir / "results.jsonl"
    failures_path = args.output_dir / "failures.jsonl"

    ok = failed = warned = total_attempts = 0
    with results_path.open("w", encoding="utf-8") as res_f, failures_path.open("w", encoding="utf-8") as fail_f:
        for t in tickets:
            r = extract_ticket(t["id"], t["text"], max_attempts=args.max_attempts)
            total_attempts += r.attempts
            if r.ok:
                ok += 1
                warned += bool(r.warnings)
                res_f.write(r.to_json() + "\n")
                f = r.fields
                print(f"{t['id']}  {f['category']:<13} {f['priority']:<7} attempts={r.attempts} "
                      f"{'WARN ' if r.warnings else ''}{f['summary']}")
            else:
                failed += 1
                fail_f.write(r.to_json() + "\n")
                print(f"{t['id']}  FAILED: {r.error}")

    n = len(tickets) or 1
    print(f"\nProcessed {len(tickets)} | ok={ok} failed={failed} with_warnings={warned} "
          f"| avg attempts={total_attempts / n:.2f}")
    print(f"Results: {results_path}   Failures: {failures_path}")


if __name__ == "__main__":
    main()
