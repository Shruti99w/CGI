"""Post-checks that catch unsupported or fabricated output.

The model is told to copy identifiers verbatim. Here code verifies it:
  - customer_name, customer_email and order_id must actually appear in the ticket
  - every evidence quote must be a verbatim substring of the ticket
Anything that fails is removed and reported as a warning. Never trust, verify.
"""
import re

from module2.schemas import TicketFields


def _norm(text: str) -> str:
    return " ".join(text.lower().split())


def check_grounding(fields: TicketFields, ticket_text: str) -> tuple[TicketFields, list[str]]:
    source = _norm(ticket_text)
    warnings: list[str] = []
    updates: dict = {}

    for name in ("customer_name", "customer_email"):
        value = getattr(fields, name)
        if value and _norm(value) not in source:
            warnings.append(f"{name}={value!r} not found in ticket -> set to null")
            updates[name] = None

    if fields.order_id:
        digits = re.sub(r"\D", "", fields.order_id)
        if digits not in re.sub(r"\D", " ", ticket_text).split():
            warnings.append(f"order_id={fields.order_id!r} not found in ticket -> set to null")
            updates["order_id"] = None

    kept = []
    for ev in fields.evidence:
        if _norm(ev.quote) in source:
            kept.append(ev)
        else:
            warnings.append(f"evidence for {ev.field} is not a verbatim quote -> dropped")
    updates["evidence"] = kept

    return fields.model_copy(update=updates), warnings
