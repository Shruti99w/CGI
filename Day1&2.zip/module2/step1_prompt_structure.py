"""Module 2 / Step 1 - Instruction structure, system prompts and few-shot examples.

Run:  uv run python -m module2.step1_prompt_structure

Three prompts classify the same tickets:
  VAGUE       "Classify this ticket"  -> format and labels drift
  STRUCTURED  system prompt with role, task, labels, rules, output format, delimiters
  FEW-SHOT    structured + worked examples that calibrate the edge cases
"""
from common.llm import chat, setup_logging

TICKETS = [
    "I was charged twice for order ORD-771204! Fix this NOW or I'm disputing with my bank.",
    "Hello team, the new tracking page is great. Maybe show the courier's phone number too?",
    "Our whole office (40+ users) cannot log in to the business portal since 9am. Error 503.",
]

STRUCTURED_SYSTEM = """# Role
You are a support triage assistant for Acme Store.

# Task
Classify the ticket inside <ticket> tags.

# Labels
category: billing | technical | account | shipping | product_issue | feedback | other
priority: low | medium | high | urgent

# Rules
- urgent: outage for many users, security or legal threat
- high: customer blocked or charged incorrectly
- medium: needs action, customer not blocked
- low: question, feedback or suggestion

# Output format
Exactly one line: <category>|<priority>
No other text."""

FEW_SHOT = [
    ("My password reset email never arrives, so I can't sign in.", "account|high"),
    ("Could you add a dark mode to the app? Love it otherwise.", "feedback|low"),
]


def vague(ticket: str):
    return chat([{"role": "user", "content": f"Classify this ticket: {ticket}"}], temperature=0)


def structured(ticket: str):
    return chat(
        [
            {"role": "system", "content": STRUCTURED_SYSTEM},
            {"role": "user", "content": f"<ticket>\n{ticket}\n</ticket>"},
        ],
        temperature=0,
    )


def few_shot(ticket: str):
    messages = [{"role": "system", "content": STRUCTURED_SYSTEM}]
    for example, label in FEW_SHOT:  # examples go in as prior user/assistant turns
        messages.append({"role": "user", "content": f"<ticket>\n{example}\n</ticket>"})
        messages.append({"role": "assistant", "content": label})
    messages.append({"role": "user", "content": f"<ticket>\n{ticket}\n</ticket>"})
    return chat(messages, temperature=0)


def main() -> None:
    setup_logging()
    for ticket in TICKETS:
        print(f"\n{'=' * 70}\nTICKET: {ticket}")
        for name, fn in (("VAGUE", vague), ("STRUCTURED", structured), ("FEW-SHOT", few_shot)):
            resp = fn(ticket)
            text = resp.choices[0].message.content.strip().replace("\n", " ")
            print(f"  {name:<11} ({resp.usage.prompt_tokens:>4} prompt tokens) {text[:150]}")
    print("\nDiscuss: Which output could a program parse reliably? What did the few-shot "
          "examples cost in tokens, and what did they buy?")


if __name__ == "__main__":
    main()
