"""Module 2 / Step 2 - Chain-of-thought and step-back prompting.

Run:  uv run python -m module2.step2_reasoning_prompts

A refund decision that needs several rules applied in the right order.
  DIRECT       answer immediately      -> often fixates on "45 days > 30 days"
  CoT          reason step by step, then a machine-readable FINAL line
  STEP-BACK    first ask for the general rules, then apply them to the case

Production notes:
  - Parse only the FINAL line; never show raw reasoning to customers.
  - Reasoning models (o-series and similar) reason internally, so you usually
    don't need "think step by step" with them. Just ask for the final format.
"""
import re

from common.llm import chat, setup_logging

POLICY = """Refund policy:
1. Unused items can be returned for a full refund within 30 days of delivery.
2. Defective items are covered by a 1-year warranty: free replacement or full refund,
   with proof of purchase.
3. Shipping fees are non-refundable, unless the item is defective.
4. Digital products cannot be refunded once downloaded."""

CASE = ("I bought headphones (order ORD-482913) 45 days ago. The left earcup stopped working "
        "last week. I have the invoice. I want a refund including the $8 shipping fee.")

FINAL_RE = re.compile(r"^FINAL:\s*(.+)$", re.MULTILINE)


def ask(messages: list[dict]) -> str:
    return chat(messages, temperature=0).choices[0].message.content.strip()


def direct() -> str:
    return ask([{"role": "user", "content": f"{POLICY}\n\nCase: {CASE}\n\n"
                 "Is a refund with shipping allowed? Answer in one line."}])


def chain_of_thought() -> tuple[str, str | None]:
    out = ask([{"role": "user", "content": f"{POLICY}\n\nCase: {CASE}\n\n"
                "Think step by step: list the relevant facts, check each policy rule, then decide. "
                "End with exactly one line: FINAL: <decision> - <one-sentence reason>"}])
    m = FINAL_RE.search(out)
    return out, (m.group(1).strip() if m else None)


def step_back() -> tuple[str, str]:
    # Step back: what general principles apply? Then apply them.
    principles = ask([{"role": "user", "content": f"{POLICY}\n\nBefore looking at any specific case: "
                       "what questions must be answered, in what order, to decide a refund under this "
                       "policy? List them briefly."}])
    decision = ask([
        {"role": "user", "content": f"{POLICY}\n\nDecision checklist:\n{principles}\n\nCase: {CASE}\n\n"
         "Answer each checklist question for this case, then end with one line: "
         "FINAL: <decision> - <one-sentence reason>"},
    ])
    return principles, decision


def main() -> None:
    setup_logging()
    print("DIRECT:\n ", direct())

    full, final = chain_of_thought()
    print("\nCHAIN-OF-THOUGHT (full output, internal only):\n", full)
    print("\n-> Parsed FINAL line (what the app shows):", final or "NOT FOUND - retry or escalate")

    principles, decision = step_back()
    print("\nSTEP-BACK principles:\n", principles)
    print("\nSTEP-BACK decision:\n", decision)

    print("\nExpected: refund allowed under the warranty (item is defective, invoice available), "
          "and shipping is refundable because the item is defective.")


if __name__ == "__main__":
    main()
