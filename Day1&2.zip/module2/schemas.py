"""Data contract for support-ticket extraction.

The Pydantic model is the single source of truth:
  - it generates the JSON Schema we send to the model (shape)
  - its validators enforce business rules the schema can't express
  - downstream code gets typed objects, not loose dicts
"""
import re
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

EMAIL_RE = re.compile(r"[^@\s]+@[^@\s]+\.[A-Za-z]{2,}")
ORDER_RE = re.compile(r"ORD-\d{6}")

Category = Literal["billing", "technical", "account", "shipping", "product_issue", "feedback", "other"]
Priority = Literal["low", "medium", "high", "urgent"]
Sentiment = Literal["positive", "neutral", "negative"]


class Evidence(BaseModel):
    model_config = ConfigDict(extra="forbid")
    field: Literal["customer_name", "customer_email", "order_id", "product"]
    quote: str = Field(description="Exact text copied verbatim from the ticket")


class TicketFields(BaseModel):
    model_config = ConfigDict(extra="forbid")

    customer_name: str | None = Field(description="Customer's name if stated, else null")
    customer_email: str | None = Field(description="Email address if stated, else null")
    order_id: str | None = Field(description="Order id like ORD-123456 if stated, else null")
    product: str | None = Field(description="Product mentioned, else null")
    category: Category
    priority: Priority
    sentiment: Sentiment
    summary: str = Field(description="One neutral sentence, at most 25 words")
    evidence: list[Evidence] = Field(description="Verbatim quotes supporting each non-null identifier")

    @field_validator("customer_email")
    @classmethod
    def valid_email(cls, v: str | None) -> str | None:
        if v is not None and not EMAIL_RE.fullmatch(v.strip()):
            raise ValueError("must be a valid email address, or null if none is given")
        return v.strip() if v else v

    @field_validator("order_id")
    @classmethod
    def valid_order_id(cls, v: str | None) -> str | None:
        if v is None:
            return v
        v = v.strip().upper()
        if not ORDER_RE.fullmatch(v):
            raise ValueError("must look like ORD-123456 (ORD- followed by 6 digits), or null")
        return v

    @field_validator("summary")
    @classmethod
    def short_summary(cls, v: str) -> str:
        if len(v.split()) > 25:
            raise ValueError(f"must be at most 25 words (got {len(v.split())})")
        return v.strip()
