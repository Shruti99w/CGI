"""Module 2 / Step 4 - Parsing, validation and retries.

Run:  uv run python -m module2.step4_validate_and_retry --offline   (no API key needed)
      uv run python -m module2.step4_validate_and_retry             (real model)

Offline mode scripts three model replies so you can watch the loop:
  attempt 1: JSON wrapped in ```fences          -> parse error
  attempt 2: valid JSON, bad email and order id -> validation errors
  attempt 3: corrected                          -> success
Each failure's exact errors are sent back to the model as feedback.

Online mode uses JSON mode (not strict) with a messy ticket, so business-rule
validation has real work to do.
"""
import json
import sys

from common.fake_client import FakeClient
from common.llm import setup_logging
from common.structured import StructuredOutputError, call_structured
from module2.schemas import TicketFields

MESSY_TICKET = ("yo its rahul, email rahul dot verma at gmail dot com, order no. 77-1204 "
                "got charged 2 times for the same shoes!!! sort it out")

GOOD = {
    "customer_name": "rahul", "customer_email": None, "order_id": None, "product": "shoes",
    "category": "billing", "priority": "high", "sentiment": "negative",
    "summary": "Customer was charged twice for the same pair of shoes.",
    "evidence": [{"field": "customer_name", "quote": "its rahul"}, {"field": "product", "quote": "shoes"}],
}
BAD_FIELDS = {**GOOD, "customer_email": "rahul dot verma at gmail dot com", "order_id": "77-1204"}

MESSAGES = [
    {"role": "system", "content": "Extract support ticket fields as JSON with keys: customer_name, "
     "customer_email, order_id, product, category (billing|technical|account|shipping|product_issue|"
     "feedback|other), priority (low|medium|high|urgent), sentiment (positive|neutral|negative), "
     "summary (max 25 words), evidence (list of {field, quote}). Use null when a value is absent."},
    {"role": "user", "content": MESSY_TICKET},
]


def main() -> None:
    setup_logging()
    offline = "--offline" in sys.argv
    client = None
    if offline:
        client = FakeClient([
            "```json\n" + json.dumps(GOOD) + "\n```",
            json.dumps(BAD_FIELDS),
            json.dumps(GOOD),
        ])

    try:
        result = call_structured(
            MESSAGES, TicketFields, mode="json_object", max_attempts=3,
            client=client, model="offline-demo" if offline else None,
        )
    except StructuredOutputError as e:
        print(f"\nGave up after {e.attempts} attempts. Route to a human review queue.\n{e}")
        return

    print(f"\nSUCCESS after {result.attempts} attempt(s):")
    print(json.dumps(result.value.model_dump(), indent=2))
    if client:
        print("\nFeedback the model received before its last attempt:")
        print(client.calls[-1]["messages"][-1]["content"])


if __name__ == "__main__":
    main()
