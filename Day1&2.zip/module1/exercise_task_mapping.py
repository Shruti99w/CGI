"""Module 1 / EXERCISE - Map three tasks to a prompt, a workflow or an agent.

Run:  uv run python -m module1.exercise_task_mapping

1. Read the three tasks below.
2. Fill in STUDENT_ANSWERS: a choice ("prompt", "workflow" or "agent") and a
   justification that uses the decision criteria.
3. Run the script. An LLM "second reviewer" maps the same tasks against the
   same rubric, and you compare. The LLM is not the answer key: where you
   disagree, decide who argued better.
"""
import sys
from typing import Literal

from pydantic import BaseModel

from common.llm import setup_logging
from common.structured import call_structured

TASKS = {
    "T1": "An employee asks the internal assistant: 'How many sick days do I get per year?' "
          "The answer is on one page of the HR leave policy.",
    "T2": "Every Monday at 9am, pull last week's IT helpdesk tickets, group them into themes, "
          "and email the top 5 themes with ticket counts to the IT manager.",
    "T3": "An employee says: 'Plan my 3-day client visit to Singapore next month within company "
          "policy.' The assistant must check the travel and expense policies, work out the "
          "approvals and budget, and ask follow-up questions if details are missing.",
}

# TODO: fill these in before running.
STUDENT_ANSWERS = {
    "T1": {"choice": "", "justification": ""},
    "T2": {"choice": "", "justification": ""},
    "T3": {"choice": "", "justification": ""},
}

RUBRIC = """Decision criteria:
- PROMPT: a single step; everything needed fits in the context (possibly with a retrieved
  document); no decisions about which tools to use.
- WORKFLOW: the steps are known in advance and the same every time; it must be
  predictable, repeatable, auditable; may include LLM calls inside fixed steps.
- AGENT: the next step depends on what was found; multiple tools or lookups; open-ended
  goal; may need to ask clarifying questions. Accept higher cost and variability.
- Avoid agents for deterministic logic (write code) and for high-risk, irreversible actions
  (require human approval)."""


class Mapping(BaseModel):
    task_id: Literal["T1", "T2", "T3"]
    choice: Literal["prompt", "workflow", "agent"]
    justification: str
    main_risk: str


class MappingList(BaseModel):
    mappings: list[Mapping]


def main() -> None:
    setup_logging()
    missing = [t for t, a in STUDENT_ANSWERS.items()
               if a["choice"] not in ("prompt", "workflow", "agent") or not a["justification"].strip()]
    if missing:
        print(f"Fill in STUDENT_ANSWERS for {', '.join(missing)} in {__file__} first.\n")
        for tid, text in TASKS.items():
            print(f"{tid}: {text}\n")
        print(RUBRIC)
        sys.exit(1)

    tasks_text = "\n".join(f"{tid}: {text}" for tid, text in TASKS.items())
    review = call_structured(
        [
            {"role": "system", "content": f"You are a solutions architect.\n{RUBRIC}\n"
             "Map each task to exactly one approach. Justify in at most 2 sentences "
             "referring to the criteria, and name the main risk of your choice."},
            {"role": "user", "content": tasks_text},
        ],
        MappingList,
    ).value

    agree = 0
    for m in sorted(review.mappings, key=lambda x: x.task_id):
        mine = STUDENT_ANSWERS[m.task_id]
        same = mine["choice"] == m.choice
        agree += same
        print(f"\n{m.task_id}: {TASKS[m.task_id][:80]}...")
        print(f"  YOU : {mine['choice']:<9} {mine['justification']}")
        print(f"  LLM : {m.choice:<9} {m.justification}")
        print(f"        risk: {m.main_risk}")
        print(f"  {'AGREE' if same else 'DIFFERENT - discuss which justification is stronger'}")
    print(f"\nAgreement: {agree}/{len(TASKS)}")


if __name__ == "__main__":
    main()
