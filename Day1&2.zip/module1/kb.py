"""A tiny internal knowledge base: markdown policy files + keyword search.

Production systems use embeddings and a vector store, but the contract is the
same: search(query) -> ranked snippets with ids, read(doc_id) -> full text.
"""
import re
from functools import lru_cache
from pathlib import Path

KB_DIR = Path(__file__).resolve().parent / "data" / "kb"

_STOPWORDS = {
    "a", "an", "the", "and", "or", "of", "to", "in", "for", "on", "at", "is", "are",
    "do", "does", "i", "my", "me", "we", "you", "can", "how", "what", "when", "much",
    "many", "with", "be", "it", "this", "that", "need", "get", "next", "month",
}


def _tokens(text: str) -> set[str]:
    return {t for t in re.findall(r"[a-z0-9]+", text.lower()) if t not in _STOPWORDS}


@lru_cache(maxsize=1)
def load_docs() -> dict[str, str]:
    docs = {p.stem: p.read_text(encoding="utf-8") for p in sorted(KB_DIR.glob("*.md"))}
    if not docs:
        raise FileNotFoundError(f"no knowledge base files found in {KB_DIR}")
    return docs


def list_doc_ids() -> list[str]:
    return list(load_docs())


def search(query: str, k: int = 3) -> list[dict]:
    """Rank documents by keyword overlap with the query."""
    q = _tokens(query)
    results = []
    for doc_id, text in load_docs().items():
        score = len(q & _tokens(text))
        if score:
            title = text.splitlines()[0].lstrip("# ").strip()
            results.append({"doc_id": doc_id, "title": title, "score": score})
    results.sort(key=lambda r: r["score"], reverse=True)
    return results[:k]


def read(doc_id: str) -> str:
    docs = load_docs()
    if doc_id not in docs:
        raise KeyError(f"unknown doc_id '{doc_id}'. Valid ids: {', '.join(docs)}")
    return docs[doc_id]
