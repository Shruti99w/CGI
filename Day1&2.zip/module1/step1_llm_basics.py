"""Module 1 / Step 1 - What an LLM does: the prompt -> completion cycle.

Run:  uv run python -m module1.step1_llm_basics

What you will see:
  1. A request is a list of messages; the response is a completion + token usage.
  2. The model samples the next token: temperature changes how random that is.
  3. Output length is capped by tokens; finish_reason tells you why it stopped.
  4. The model is stateless: it only knows what you send in this request.
"""
from common.llm import chat, setup_logging


def section(title: str) -> None:
    print(f"\n{'=' * 70}\n{title}\n{'=' * 70}")


def main() -> None:
    setup_logging()

    section("1. One prompt -> one completion")
    messages = [
        {"role": "system", "content": "You are a concise assistant for Acme Corp employees."},
        {"role": "user", "content": "In one sentence, what does a large language model do?"},
    ]
    resp = chat(messages, temperature=0)
    print("Completion   :", resp.choices[0].message.content)
    print("Finish reason:", resp.choices[0].finish_reason)
    u = resp.usage
    print(f"Tokens       : prompt={u.prompt_tokens} completion={u.completion_tokens} total={u.total_tokens}")
    print("-> You pay for prompt + completion tokens. Long system prompts cost money on every call.")

    section("2. Sampling: temperature 0 vs 1.2 (3 completions each)")
    prompt = [{"role": "user", "content": "Suggest a name for an internal helpdesk chatbot. One word only."}]
    for temp in (0, 1.2):
        resp = chat(prompt, temperature=temp, n=3)
        names = [c.message.content.strip() for c in resp.choices]
        print(f"temperature={temp}: {names}")
    print("-> Use low temperature for extraction/classification, higher for brainstorming.")

    section("3. Token limit: finish_reason = 'length'")
    resp = chat(
        [{"role": "user", "content": "Explain how cloud computing works."}],
        max_completion_tokens=25,
    )
    print("Completion   :", resp.choices[0].message.content)
    print("Finish reason:", resp.choices[0].finish_reason)
    print("-> In production, always check finish_reason. 'length' means the answer is cut off.")

    section("4. The model is stateless")
    first = [{"role": "user", "content": "My name is Priya and I work in the finance team."}]
    reply = chat(first, temperature=0).choices[0].message.content
    without_history = chat([{"role": "user", "content": "Which team do I work in?"}], temperature=0)
    print("Without history:", without_history.choices[0].message.content)
    with_history = chat(
        first
        + [{"role": "assistant", "content": reply}]
        + [{"role": "user", "content": "Which team do I work in?"}],
        temperature=0,
    )
    print("With history   :", with_history.choices[0].message.content)
    print("-> 'Memory' is just your application re-sending the conversation every time.")


if __name__ == "__main__":
    main()
