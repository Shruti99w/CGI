# Expense Policy (FIN-220)

- Meal per diem: USD 75 per day for international travel, INR 2,000 per day for domestic travel.
- Submit expense claims within 30 days of the expense, with itemised receipts for any item above USD 25 or INR 500.
- Not reimbursable: alcohol, personal entertainment, traffic fines, upgrades not allowed by the Travel Policy.
- Client entertainment needs prior approval from your manager, and the client's name must be on the claim.
- Approved claims are paid with the next payroll.
- Questions: finance@acme.example
