# Business Travel Policy (FIN-210)

- All business travel must be pre-approved by your manager in the Travel portal before booking.
- International travel also needs approval from the department head and must be booked at least 14 days in advance.
- Flights: economy class for flights under 6 hours; premium economy is allowed for flights over 6 hours.
- Hotels: up to USD 180 per night in tier-1 cities (Singapore, London, New York, Tokyo) and USD 120 per night elsewhere.
- Employees are responsible for a valid passport and visa. The Travel desk can issue invitation letters for visa applications.
- Meal allowances are covered by the Expense Policy (FIN-220).
- Questions: travel@acme.example
