# Leave Policy (HR-101)

- Full-time employees get 24 days of paid annual leave per calendar year.
- Employees in their first year get 18 days of annual leave, pro-rated from the joining date.
- Up to 5 unused annual leave days can be carried over to the next year. Carried-over days expire on 31 March.
- Sick leave: 12 days per year. A medical certificate is required for absences longer than 2 consecutive days.
- Annual leave requests must be submitted in the HR portal at least 5 working days in advance.
- Parental leave: 26 weeks for the primary caregiver, 4 weeks for the secondary caregiver.
- Questions: hr@acme.example
