# IT Access Policy (IT-305)

- Request access to any internal system through the IT Service Portal. Your manager must approve the request.
- Production database access also needs approval from the data owner and is limited to 7 days at a time.
- Password reset is self-service in the IT Service Portal. MFA is mandatory for all accounts.
- Report a lost or stolen laptop to IT Security within 24 hours at security@acme.example.
- Never share credentials. Access rights are reviewed every quarter.
