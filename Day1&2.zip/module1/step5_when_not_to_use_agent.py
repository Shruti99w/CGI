"""Module 1 / Step 5 - When NOT to use an agent.

Run:  uv run python -m module1.step5_when_not_to_use_agent

Part A - Deterministic tasks: if the rule fits in an if-statement, write code.
         It's free, instant, testable and always gives the same answer.
Part B - High-risk tasks: the LLM may *propose* an action, but code checks it
         against an allowlist and a human approves before anything executes.
         Every decision is written to an audit log.
"""
import json
from datetime import date, datetime
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field

from common.llm import setup_logging
from common.structured import call_structured

# ---------------------------------------------------------------- Part A
PER_DIEM = {"international": 75.0, "domestic_inr": 2000.0}


def first_year_leave_days(joining: date, annual_days: int = 18) -> float:
    """Pro-rated first-year leave. Pure code: no LLM needed."""
    months_remaining = 12 - joining.month + 1
    return round(annual_days * months_remaining / 12, 1)


def meal_claim_ok(trip_type: str, days: int, amount: float) -> tuple[bool, str]:
    limit = PER_DIEM[trip_type] * days
    if amount <= limit:
        return True, f"within limit ({amount} <= {limit})"
    return False, f"over limit by {amount - limit:.2f} (limit {limit})"


# ---------------------------------------------------------------- Part B
AUDIT_LOG = Path("out/audit.log")

ACTION_POLICY = {
    "reset_password": "auto",            # low risk, user can undo
    "grant_prod_db_access": "approval",  # high risk: human must approve
    "delete_user_account": "blocked",    # irreversible: never via chatbot
    "none": "auto",
}


class ProposedAction(BaseModel):
    action: Literal["reset_password", "grant_prod_db_access", "delete_user_account", "none"]
    target_user: str | None = Field(description="Username the action applies to, or null")
    reason: str = Field(description="One short sentence explaining the request")


def audit(entry: dict) -> None:
    AUDIT_LOG.parent.mkdir(parents=True, exist_ok=True)
    entry = {"ts": datetime.now().isoformat(timespec="seconds"), **entry}
    with AUDIT_LOG.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")


def handle_request(text: str) -> None:
    print(f"\nREQUEST: {text}")
    proposal = call_structured(
        [
            {"role": "system", "content": "Map the IT request to exactly one action. "
             "Use 'none' if no listed action fits. Do not perform anything."},
            {"role": "user", "content": text},
        ],
        ProposedAction,
    ).value
    policy = ACTION_POLICY[proposal.action]
    print(f"LLM PROPOSES: {proposal.model_dump()}  -> policy: {policy}")

    if policy == "blocked":
        decision = "rejected: action not allowed via assistant; raise a ticket with IT"
    elif policy == "approval":
        ok = input("  Human approver, execute this action? [y/N] ").strip().lower() == "y"
        decision = "approved and executed" if ok else "rejected by approver"
    else:
        decision = "executed automatically"
    print(f"DECISION: {decision}")
    audit({"request": text, "proposal": proposal.model_dump(), "policy": policy, "decision": decision})


def main() -> None:
    setup_logging()
    print("PART A - deterministic rules in plain code")
    print("  Joined 1 Jul -> leave days:", first_year_leave_days(date(2026, 7, 1)))
    print("  Joined 15 Oct -> leave days:", first_year_leave_days(date(2026, 10, 15)))
    print("  3-day intl trip, $240 meals ->", meal_claim_ok("international", 3, 240))
    print("  3-day intl trip, $200 meals ->", meal_claim_ok("international", 3, 200))

    print("\nPART B - high-risk actions: LLM proposes, code + human decide")
    for request in [
        "I forgot my password, please reset it. My username is priya.s",
        "Give rahul.k access to the production customer database, he needs it for a report.",
        "Delete the account of amit.p, he left the company.",
    ]:
        handle_request(request)
    print(f"\nAudit trail written to {AUDIT_LOG}")


if __name__ == "__main__":
    main()
