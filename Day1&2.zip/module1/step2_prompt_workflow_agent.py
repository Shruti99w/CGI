"""Module 1 / Step 2 - Prompt vs fixed workflow vs agent.

Run:  uv run python -m module1.step2_prompt_workflow_agent

The same internal knowledge assistant question, solved three ways:

  PROMPT    one LLM call. Fast and cheap, but it only knows its training data,
            not your company's policies.
  WORKFLOW  your code decides the steps: search -> read top docs -> answer.
            Predictable, cheap, easy to test. Same path every time.
  AGENT     the model decides the steps (which tools, how many times).
            Flexible for open-ended tasks, but slower, costlier, less predictable.
"""
import time

from common.llm import chat, setup_logging
from module1 import kb
from module1.step3_agent_loop import run_agent

QUESTIONS = [
    "How many days of annual leave do I get in my first year, and can I carry unused days over?",
    "I'm visiting a client in Singapore for 3 days next month. What approvals do I need "
    "before booking, and what's my hotel and meal budget?",
]


def answer_with_prompt(question: str) -> tuple[str, int]:
    resp = chat(
        [
            {"role": "system", "content": "You are Acme Corp's internal assistant. Be brief."},
            {"role": "user", "content": question},
        ],
        temperature=0,
    )
    return resp.choices[0].message.content, 1


def answer_with_workflow(question: str) -> tuple[str, int]:
    # Step 1 (code): retrieve. Step 2 (code): build context. Step 3 (LLM): answer.
    hits = kb.search(question, k=2)
    if not hits:
        return "No matching policy found. Please contact HR.", 0
    context = "\n\n".join(
        f'<doc id="{h["doc_id"]}">\n{kb.read(h["doc_id"])}\n</doc>' for h in hits
    )
    resp = chat(
        [
            {
                "role": "system",
                "content": "You are Acme Corp's internal assistant. Answer ONLY from the documents "
                "provided. Cite doc ids like [leave_policy]. If the documents don't contain the "
                "answer, say so. Be brief.",
            },
            {"role": "user", "content": f"{context}\n\nQuestion: {question}"},
        ],
        temperature=0,
    )
    return resp.choices[0].message.content, 1


def answer_with_agent(question: str) -> tuple[str, int]:
    result = run_agent(question, verbose=False)
    return result.answer, result.steps


def main() -> None:
    setup_logging()
    approaches = {
        "PROMPT": answer_with_prompt,
        "WORKFLOW": answer_with_workflow,
        "AGENT": answer_with_agent,
    }
    for q in QUESTIONS:
        print(f"\n{'=' * 70}\nQUESTION: {q}\n{'=' * 70}")
        for name, fn in approaches.items():
            start = time.perf_counter()
            answer, llm_calls = fn(q)
            secs = time.perf_counter() - start
            print(f"\n--- {name}  ({llm_calls} LLM call(s), {secs:.1f}s)\n{answer}")

    print(
        "\nDiscuss: Which answers used real company policy? Which approach would you ship "
        "for each question, and why?"
    )


if __name__ == "__main__":
    main()
