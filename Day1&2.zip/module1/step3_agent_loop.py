"""Module 1 / Step 3 - The agent loop: goal -> plan -> act -> observe -> repeat.

Run:  uv run python -m module1.step3_agent_loop
      uv run python -m module1.step3_agent_loop "How do I get production DB access?"

The internal knowledge assistant gets a goal (the employee's question) and two
tools. The model decides which tool to call; our code executes it and feeds the
result back. The loop ends when the model answers without calling a tool, or
when the step budget runs out.

Production guardrails in this file:
  - a hard step limit (agents can loop forever and burn tokens)
  - tool errors are returned to the model as data, not raised (it can recover)
  - tool arguments are parsed defensively (the model can produce bad JSON)
  - every step is logged so you can trace why the agent did what it did
"""
import json
import sys
from dataclasses import dataclass, field

from common.llm import chat, setup_logging
from module1 import kb

SYSTEM_PROMPT = """You are the internal knowledge assistant for Acme Corp employees.

Goal: answer the employee's question using ONLY the company knowledge base.

How to work:
1. Before calling tools, state a one-line plan.
2. Use search_kb to find relevant documents, then read_doc to read them.
3. Look at what you found. If something is missing, search again.
4. When you have enough evidence, answer.

Rules:
- Cite the documents you used like [leave_policy].
- If the knowledge base does not contain the answer, say so and point the
  employee to the right team. Never invent numbers or policies.
- Keep the final answer short and practical."""

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "search_kb",
            "description": "Search the company knowledge base. Returns matching document ids and titles.",
            "parameters": {
                "type": "object",
                "properties": {"query": {"type": "string", "description": "Keywords to search for"}},
                "required": ["query"],
                "additionalProperties": False,
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_doc",
            "description": "Read the full text of one knowledge base document by its id.",
            "parameters": {
                "type": "object",
                "properties": {"doc_id": {"type": "string", "description": "Id returned by search_kb"}},
                "required": ["doc_id"],
                "additionalProperties": False,
            },
        },
    },
]

TOOL_FUNCTIONS = {
    "search_kb": lambda args: kb.search(args["query"]),
    "read_doc": lambda args: kb.read(args["doc_id"]),
}


@dataclass
class AgentResult:
    answer: str
    steps: int
    tool_calls: list[str] = field(default_factory=list)
    completed: bool = True


def run_tool(name: str, raw_args: str) -> str:
    """Execute a tool call. Errors go back to the model as text so it can adapt."""
    try:
        args = json.loads(raw_args or "{}")
        func = TOOL_FUNCTIONS[name]
        result = func(args)
        return result if isinstance(result, str) else json.dumps(result)
    except KeyError as e:
        return json.dumps({"error": f"bad tool or argument: {e}"})
    except json.JSONDecodeError:
        return json.dumps({"error": "arguments were not valid JSON"})
    except Exception as e:  # never let one tool failure crash the agent
        return json.dumps({"error": f"{type(e).__name__}: {e}"})


def run_agent(question: str, *, max_steps: int = 6, verbose: bool = True,
              client=None, model: str | None = None) -> AgentResult:
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": question},
    ]
    calls_made: list[str] = []
    if verbose:
        print(f"\nGOAL: {question}")

    for step in range(1, max_steps + 1):
        resp = chat(messages, tools=TOOLS, temperature=0, client=client, model=model)
        msg = resp.choices[0].message

        if not msg.tool_calls:  # no more actions: this is the final answer
            if verbose:
                print(f"\n[step {step}] ANSWER:\n{msg.content}")
            return AgentResult(answer=msg.content or "", steps=step, tool_calls=calls_made)

        if verbose and msg.content:
            print(f"\n[step {step}] PLAN: {msg.content.strip()}")

        # Keep the assistant's tool request in history; the API requires it
        # before the matching tool results.
        messages.append({
            "role": "assistant",
            "content": msg.content,
            "tool_calls": [
                {"id": tc.id, "type": "function",
                 "function": {"name": tc.function.name, "arguments": tc.function.arguments}}
                for tc in msg.tool_calls
            ],
        })

        for tc in msg.tool_calls:
            calls_made.append(f"{tc.function.name}({tc.function.arguments})")
            if verbose:
                print(f"[step {step}] ACT: {tc.function.name}({tc.function.arguments})")
            result = run_tool(tc.function.name, tc.function.arguments)
            if verbose:
                preview = result.replace("\n", " ")
                print(f"[step {step}] OBSERVE: {preview[:160]}{'...' if len(preview) > 160 else ''}")
            messages.append({"role": "tool", "tool_call_id": tc.id, "content": result})

    return AgentResult(
        answer="I couldn't finish within the step limit. Please contact the relevant team.",
        steps=max_steps, tool_calls=calls_made, completed=False,
    )


def main() -> None:
    setup_logging()
    questions = sys.argv[1:] or [
        "I'm visiting a client in Singapore for 3 days next month. What approvals do I need "
        "before booking, and what's my hotel and meal budget?",
        "What is the company policy on bringing pets to the office?",  # not in the KB
    ]
    for q in questions:
        result = run_agent(q)
        print(f"\n-> steps={result.steps} tool_calls={len(result.tool_calls)} completed={result.completed}")
        print("-" * 70)


if __name__ == "__main__":
    main()
