"""Module 1 / Step 4 - Model families and selection.

Run:  uv run python -m module1.step4_model_selection

Runs the same two tasks on each model in OPENAI_COMPARE_MODELS and prints
latency, tokens and answers. Pick the smallest model that passes your quality bar.

Model families at a high level:
  small / fast     (e.g. gpt-4o-mini)       classification, extraction, routing, high volume
  large / general  (e.g. gpt-4o, gpt-4.1)   harder writing, nuanced instructions, tool use
  reasoning        (e.g. o-series)          multi-step logic, maths, planning; slower and costlier
  open-weight      (e.g. Llama, gpt-oss)    self-hosting, data residency, cost control

Selection checklist: quality on YOUR examples, latency budget, cost per 1K calls,
context window, tool/structured-output support, data and compliance rules.
"""
import os
import time

from common.llm import chat, setup_logging

TASKS = {
    "simple": "Classify this IT ticket as one of: access, hardware, software, network. "
              "Reply with the label only.\nTicket: 'My laptop screen flickers when I unplug the charger.'",
    "reasoning": "An employee joined on 1 July. First-year employees get 18 days of annual leave "
                 "per year, pro-rated from the joining date. How many days do they get this "
                 "calendar year? Show the calculation in two lines, then give the number.",
}


def main() -> None:
    setup_logging()
    models = [m.strip() for m in os.getenv("OPENAI_COMPARE_MODELS", "gpt-4o-mini,gpt-4o").split(",") if m.strip()]
    rows = []
    for model in models:
        for task_name, prompt in TASKS.items():
            start = time.perf_counter()
            try:
                # No temperature here: some reasoning models only accept the default.
                resp = chat([{"role": "user", "content": prompt}], model=model)
            except Exception as e:  # model not available on this account, etc.
                rows.append((model, task_name, "-", "-", f"ERROR: {e}"))
                continue
            secs = time.perf_counter() - start
            answer = (resp.choices[0].message.content or "").strip().replace("\n", " | ")
            rows.append((model, task_name, f"{secs:.1f}s", str(resp.usage.total_tokens), answer))

    print(f"\n{'model':<16}{'task':<11}{'latency':<9}{'tokens':<8}answer")
    print("-" * 100)
    for model, task, latency, tokens, answer in rows:
        print(f"{model:<16}{task:<11}{latency:<9}{tokens:<8}{answer[:120]}")
    print("\nCorrect answer for 'reasoning': 18 x 6/12 = 9 days.")
    print("Discuss: Did the small model get both right? Is the large model worth the extra cost here?")


if __name__ == "__main__":
    main()
