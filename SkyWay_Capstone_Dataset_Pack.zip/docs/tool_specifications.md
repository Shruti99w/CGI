# Tool specifications

Implement these tools in Python over the CSV files in `data/`. Business rules live **inside the tools**,
not only in the prompt. Tools must never raise uncaught exceptions: return a clear status instead.

| Tool | Arguments | Returns | Guardrail it must enforce |
|---|---|---|---|
| `get_current_datetime` | none | `"2026-12-01T10:00:00+05:30"` | Fixed clock, never the real date |
| `get_booking` | `pnr: str`, `last_name: str` | Booking summary (PNR, passenger name, flight, route, departure, fare class, fare parts, booking status, loyalty tier, **masked** email/phone/payment method) or `{"status": "VERIFICATION_FAILED"}` | P1: same failure message for "unknown PNR" and "wrong last name" (no hint which one) |
| `get_flight_status` | `flight_no: str`, `flight_date: str (YYYY-MM-DD)` | `flight_status`, `delay_minutes` | none |
| `calculate_refund` | `pnr: str` | `eligible`, `refund_amount`, `policy_rule`, `hours_to_departure`, `needs_approval`, breakdown | All of section 1 and 2 of the policy, in code |
| `request_supervisor_approval` | `pnr: str`, `reason: str` | Runs only after a human approves (human-in-the-loop middleware). Returns an approval id such as `AP-SKX3C7` | P2 |
| `issue_refund` | `pnr: str`, `approval_id: str | None` | Ticket id `RF-<PNR>`, amount, destination = original payment method | Recalculates the amount itself (the model never passes an amount); refuses if not eligible, already refunded, or amount > 25,000 without a valid approval id; marks the booking REFUNDED in memory (idempotent) |

Notes
- `issue_refund` has **no amount argument** on purpose: the model cannot invent a number.
- Masking format: `k***@examplemail.in`, `+91 9*******12`, `CARD ****1234`.
- Reload the CSVs at the start of each evaluation case so one case's refund does not leak into the next.
